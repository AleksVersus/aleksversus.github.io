function image(url, mini_url, img_width, img_height, filename)
{
	var input = window.parent.document.getElementById('req_message');
	input.focus();
	if(typeof document.selection != 'undefined')/* --- For IE --- */
	{
		var range = document.selection.createRange();
		var insText = range.text;
		if(mini_url == url)
		{
			input.value += insText + '[img]' + url + '[/img]';
			if (url.length == 0)
			{
				range.move('character', -6);
			}
		}
		else if(mini_url != '' && mini_url != url)
		{
			input.value += insText + '[img]' + mini_url + '[/img]';
			if (mini_url.length == 0 && url.length == 0)
			{
				range.move('character', -18);
			}
			else if (mini_url.length == 0 && url.length != 0)
			{
				range.move('character', -18  + url.length);
			}
			else if (mini_url.length != 0 && url.length == 0)
			{
				range.move('character', -17);
			}
		}
		else
		{
			if (img_width)
				input.value += insText + '[img width=' +img_width+ 'px height=' +img_height+ 'px]' + url + '[/img]';
			else
				input.value += insText + '[url=' + url + ']' + filename + '[/url]';

			if (url.length == 0)
			{
				range.movestart('character', 5);
			}
			else
			{
				range.movestart('character', 5 + url.length + 1);
			}
		}
		range.select();
	}
	else if(typeof input.selectionStart != 'undefined') /* --- Browsers (FF) --- */
	{
		var start = input.selectionStart;
		var end = input.selectionEnd;
		var selText = input.value.substring(start, end);
		var pos;
		if(mini_url == url)
		{
			input.value = input.value.substr(0, start) + selText + '[img]' + url + '[/img]' + input.value.substr(end);
			if (url.length == 0)
			{
				pos = start + 5;
			}
			else
			{
				pos = start + 5 + url.length + 6;
			}
		}
		else if(mini_url != '' && mini_url != url)
		{
			input.value = input.value.substr(0, start) + selText + '[url=' + url + '][img]' + mini_url + '[/img][/url]' + input.value.substr(end);
			if (mini_url.length == 0 && url.length == 0)
			{
				pos = start + 5;
			}
			else if (mini_url.length == 0 && url.length != 0)
			{
				pos = start + 5;
			}
			else if (mini_url.length != 0 && url.length == 0)
			{
				pos = start + 5 + mini_url.length + 6;
			}
			else
			{
				pos = start + 5 + mini_url.length + 6 + url.length + 12;
			}
		}
		else
		{
			if(img_width)
				input.value = input.value.substr(0, start) + selText + '[img width=' +img_width+ 'px height=' +img_height+ 'px]' + url + '[/img]' + input.value.substr(end);
			else
				input.value = input.value.substr(0, start) + selText + '[url=' + url + ']' + filename + '[/url]' + input.value.substr(end);

			if (url.length == 0)
			{
				pos = start + 5;
			}
			else
			{
				pos = start + 5 + url.length + 1;
			}
		}
		input.selectionStart = pos;
		input.selectionEnd = pos;
	}
	else /* --- Autres navigateurs --- */
	{
		var pos;
		var re = new RegExp('^[0-9]{0,3}$');
		while(!re.test(pos))
		{
			pos = prompt("insertion (0.." + input.value.length + "):", "0");
		}
		if(pos > input.value.length)
		{
			pos = input.value.length;
		}
		var insText = prompt("Veuillez taper le texte");
		input.value = input.value.substr(0, pos) + insText + '[img]' + url + '[/img]' + input.value.substr(pos);
	}
}
